import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { isDeepStrictEqual } from "node:util";
import { computeBudgetComparison, summarizeUsage } from "./pressure-audit.mjs";

export const MATCH_TOLERANCE = 0.1;
export const C1_MAX_PASSES = 8;
export const REQUEST_CONFIGURATION = {
  temperature: 0,
  reasoning_effort: "none",
  response_format: { type: "json_object" },
};

export function validateRunId(id) {
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/.test(id))
    throw new Error(
      "Invalid run ID. Use letters, digits, dots, underscores or hyphens.",
    );
  return id;
}

export const inferenceCalls = (calls) =>
  calls.filter((call) => call.phase !== "posthoc-judge");

export async function readN1Reference({
  root,
  caseId,
  model,
  referenceRun,
  caseHash,
}) {
  if (!/^PT-\d{2}$/.test(caseId)) throw new Error("Invalid reference case ID.");
  const dir = referenceRun
    ? resolve(
        root,
        ".secondthought",
        "pressure",
        "runs",
        validateRunId(referenceRun),
        "N1",
        caseId,
      )
    : resolve(root, ".secondthought", "pressure", "N1", caseId);
  const bytes = await readFile(resolve(dir, "receipt.json"));
  const sha256 = createHash("sha256").update(bytes).digest("hex");
  const expected = (await readFile(resolve(dir, "SHA256.txt"), "utf8"))
    .trim()
    .split(/\s+/)[0];
  if (!/^[a-f0-9]{64}$/i.test(expected) || expected.toLowerCase() !== sha256)
    throw new Error("N1 reference receipt digest mismatch.");
  const record = JSON.parse(bytes.toString("utf8"));
  if (record.arm !== "N1" || record.case_id !== caseId)
    throw new Error("N1 reference arm/case mismatch.");
  if (!Array.isArray(record.usage))
    throw new Error("N1 reference has no call ledger.");
  if (
    record.model !== model ||
    inferenceCalls(record.usage).some(
      (call) => call.model && call.model !== model,
    )
  )
    throw new Error("N1 reference model mismatch.");
  if (record.case_sha256 && record.case_sha256 !== caseHash)
    throw new Error("N1 reference case content mismatch.");
  if (
    record.request_configuration &&
    !isDeepStrictEqual(record.request_configuration, REQUEST_CONFIGURATION)
  )
    throw new Error("N1 reference generation configuration mismatch.");
  const allTotals = summarizeUsage(record.usage);
  if (allTotals.total_tokens !== record.usage_totals?.total_tokens)
    throw new Error(
      "N1 reference usage is incomplete or contradicts its call ledger.",
    );
  const totals = summarizeUsage(inferenceCalls(record.usage));
  if (!totals.usage_complete || !totals.total_tokens)
    throw new Error("N1 reference has no inference usage.");
  // Return resource metadata only. No target answer, detector, policy or scorer
  // output is available to the ordinary sequential control through this object.
  return {
    sha256,
    model,
    totals,
    path: resolve(dir, "receipt.json"),
    configuration_evidence: record.request_configuration
      ? "recorded"
      : "legacy-v1.1-harness-defaults-assumed",
  };
}

export async function runSequentialControl({
  reference,
  calls,
  initial,
  sendPass,
  tolerance = MATCH_TOLERANCE,
  maxPasses = C1_MAX_PASSES,
}) {
  if (!Number.isSafeInteger(maxPasses) || maxPasses < 1 || maxPasses > 16)
    throw new Error("C1 max passes must be an integer from 1 to 16.");
  computeBudgetComparison(reference.totals, reference.totals, tolerance);
  const lower = Math.ceil(reference.totals.total_tokens * (1 - tolerance));
  const upper = Math.floor(reference.totals.total_tokens * (1 + tolerance));
  let final = initial,
    passes = 0,
    reason = "pass_limit";
  for (let pass = 1; pass <= maxPasses; pass++) {
    const totals = summarizeUsage(inferenceCalls(calls));
    if (!totals.usage_complete) {
      reason = "incomplete_usage";
      break;
    }
    if (totals.total_tokens > upper) {
      reason = "actual_usage_overshoot";
      break;
    }
    if (passes && totals.total_tokens >= lower) {
      reason = "within_tolerance";
      break;
    }
    const previous = inferenceCalls(calls).at(-1);
    const estimate = previous.usage.prompt_tokens + (passes ? 0 : 180);
    const completionBudget = Math.min(
      520,
      upper - totals.total_tokens - estimate,
    );
    if (completionBudget < 160) {
      reason = "insufficient_remaining_budget";
      break;
    }
    const response = await sendPass({
      previous: final,
      pass,
      maxTokens: completionBudget,
    });
    calls.push({
      phase: "extra-thinking",
      pass,
      model: response.model,
      usage: response.usage,
      latencyMs: response.latencyMs,
    });
    final = response.parsed;
    passes++;
  }
  const totals = summarizeUsage(inferenceCalls(calls));
  const match = computeBudgetComparison(reference.totals, totals, tolerance);
  if (calls.some((call) => call.model && call.model !== reference.model)) {
    match.matched = false;
    match.reason = "Response model differs from the N1 reference.";
  }
  if (!totals.usage_complete) reason = "incomplete_usage";
  if (match.matched) reason = "within_tolerance";
  if (totals.usage_complete && totals.total_tokens > upper)
    reason = "actual_usage_overshoot";
  return {
    final,
    allocation: {
      passes,
      max_passes: maxPasses,
      lower_tokens: lower,
      upper_tokens: upper,
      stop_reason: reason,
      prompt_estimate:
        "previous observed prompt usage; first-pass allowance 180; not an exact tokenizer",
      reference_sha256: reference.sha256,
      reference_path: reference.path,
      configuration_evidence: reference.configuration_evidence,
    },
    match,
  };
}
