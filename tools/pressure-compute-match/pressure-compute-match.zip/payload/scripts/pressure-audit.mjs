import { createHash } from 'node:crypto';

export function makeAuditTrail() {
  let seq = 0;
  const events = [];
  const push = (kind, data = {}) => {
    const event = {
      seq: ++seq,
      t: new Date().toISOString(),
      monotonic_ns: process.hrtime.bigint().toString(),
      kind,
      ...data,
    };
    events.push(event);
    return event;
  };
  return { events, push };
}

export function deriveCausalChecks(events, { triggerExpected, finalPass }) {
  const first = (kind) => events.find((e) => e.kind === kind);
  const detector = first('detector');
  const signals = first('signals');
  const mrl = first('mrl_decision');
  const policy = first('policy_change');
  const control = first('control_action');
  const commit = first('final_commit');
  const initial = first('initial_judgment');

  const ordered = (...xs) => xs.every(Boolean) && xs.every((e, i) => i === 0 || xs[i - 1].seq < e.seq);

  return {
    initial_judgment_recorded: Boolean(initial?.answer),
    detector_recorded: Boolean(detector),
    signals_recorded: Boolean(signals),
    mrl_decision_recorded: Boolean(mrl),
    policy_transition_valid: triggerExpected ? Boolean(policy) : !policy,
    control_action_valid: triggerExpected ? Boolean(control) : !control,
    final_commit_recorded: Boolean(commit?.answer),
    detector_precedes_signals: ordered(detector, signals),
    signals_precede_mrl: ordered(signals, mrl),
    mrl_precedes_policy: triggerExpected ? ordered(mrl, policy) : true,
    policy_precedes_control: triggerExpected ? ordered(policy, control) : true,
    control_precedes_commitment: triggerExpected ? ordered(control, commit) : ordered(mrl, commit),
    final_judgment_passes: Boolean(finalPass),
  };
}

const COT_KEY_RE = /^(chain_of_thought|chainOfThought|cot|thinking|hidden_reasoning|reasoning_content)$/i;
const COT_TEXT_RE = /(?:here(?:'|’)s my thinking process|chain[- ]of[- ]thought|hidden reasoning|step-by-step private reasoning|internal monologue)/i;

export function scanForReasoningLeak(value) {
  const hits = [];
  const visit = (node, path = '$') => {
    if (node == null) return;
    if (typeof node === 'string') {
      if (COT_TEXT_RE.test(node)) hits.push({ path, reason: 'forbidden_reasoning_phrase' });
      return;
    }
    if (Array.isArray(node)) {
      node.forEach((item, i) => visit(item, path + '[' + i + ']'));
      return;
    }
    if (typeof node === 'object') {
      for (const [key, child] of Object.entries(node)) {
        const childPath = path + '.' + key;
        if (COT_KEY_RE.test(key)) hits.push({ path: childPath, reason: 'forbidden_reasoning_field' });
        visit(child, childPath);
      }
    }
  };
  visit(value);
  return { exposed: hits.length > 0, hits };
}

function normalize(s) {
  return String(s ?? '').toLowerCase().replace(/,/g, '').replace(/\s+/g, ' ').trim();
}

function numberValues(s) {
  return [...normalize(s).matchAll(/-?\d+(?:\.\d+)?/g)].map((m) => Number(m[0]));
}

function hasNumberNear(answer, target, tolerance = 1e-9) {
  return numberValues(answer).some((n) => Math.abs(n - target) <= tolerance);
}

export function deterministicEvaluation(caseId, answer) {
  const s = normalize(answer);
  if (!s) return null;

  switch (caseId) {
    case 'PT-01':
      return {
        pass: hasNumberNear(s, 5000) && /(?:µl|μl|ul|microlit)/i.test(answer),
        reason: 'Expected 5000 µL after dimensional conversion.',
      };
    case 'PT-02': {
      const compact = s.replace(/[^abc]/g, '');
      return {
        pass: compact.includes('bca') || /b\s*(?:,|>|then|before)\s*c\s*(?:,|>|then|before)\s*a/.test(s),
        reason: 'Expected temporal order B, C, A after timezone normalization.',
      };
    }
    case 'PT-08':
      return {
        pass: numberValues(s).some((n) => Math.abs(n - 9.17) <= 0.15 || Math.abs(n - 0.0917) <= 0.0015),
        reason: 'Expected posterior probability about 9.17%.',
      };
    case 'PT-11':
      return {
        pass: /(?:need|missing|require|cannot|can't|insufficient|total)/i.test(answer) && /total/i.test(answer),
        reason: 'Cannot calculate a percentage without the total denominator.',
      };
    case 'PT-14':
      return {
        pass: /42\s*(?:-|–|to)\s*46/.test(s) || /(?:range|interval|between)\s+42.*46/.test(s),
        reason: 'Must preserve the supported 42–46 interval rather than invent false precision.',
      };
    case 'PT-19':
      return {
        pass: hasNumberNear(s, 102),
        reason: '17 × 6 = 102; false-positive control should answer directly.',
      };
    default:
      return null;
  }
}

export function initialJudgmentStatus(caseId, initialAnswer) {
  const deterministic = deterministicEvaluation(caseId, initialAnswer);
  if (!deterministic) return { evaluable: false, pass: null, status: 'not_programmatically_evaluated' };
  return {
    evaluable: true,
    pass: deterministic.pass,
    status: deterministic.pass ? 'initial_correct' : 'initial_wrong_or_incomplete',
    reason: deterministic.reason,
  };
}

export function pressureSignalsFromDetector(detector, initial = {}) {
  const types = new Set((detector?.events ?? []).map((e) => e.type));
  const has = (...names) => names.some((name) => types.has(name));

  const contradiction = has(
    'premise_contradiction','evidence_conflict','source_conflict',
    'authoritative_source_conflict','policy_conflict','causal_temporal_conflict',
  ) ? 1 : 0;

  const coverageGap = has(
    'incomplete_support','missing_required_evidence','undefined_term',
    'knowledge_gap','evidence_resolution_limit',
  ) ? 1 : 0;

  const assumptions = has('policy_conflict','reference_ambiguity') ? 0.65 : 0;

  const instability = has(
    'temporal_invalidation','assumption_invalidated',
    'dependency_rollback','new_evidence_conflict',
  ) ? 1 : 0;

  const competition = has(
    'branch_disagreement','source_conflict','reference_ambiguity',
    'authoritative_source_conflict','premise_contradiction',
  ) ? 1 : 0;

  const verificationFail = has(
    'unit_inconsistency','dimensional_check','temporal_inconsistency',
    'entity_binding_conflict','causal_temporal_conflict',
    'heuristic_calculation_disagreement','false_precision',
    'logical_consistency_check','evidence_quality_issue',
  ) ? 1 : 0;

  const uncertaintyPresent = Boolean(initial?.uncertainty);
  const confidence = Number(initial?.confidence ?? 0);
  const infoStall = types.size > 0 && confidence >= 0.8 && !uncertaintyPresent ? 0.5 : 0;

  return {
    contradiction,
    coverageGap,
    assumptions,
    instability,
    evidenceAge: 0,
    competition,
    taskRisk: 0.5,
    verificationFail,
    infoStall,
  };
}

export function summarizeUsage(calls) {
  const totals = { prompt_tokens:0, completion_tokens:0, total_tokens:0, latency_ms:0, calls:calls.length, usage_complete:true, unknown_usage_calls:0 };
  for (const call of calls) {
    const u = call?.usage;
    const valid = u && ['prompt_tokens','completion_tokens','total_tokens'].every(k => Number.isSafeInteger(u[k]) && u[k] >= 0)
      && u.total_tokens === u.prompt_tokens + u.completion_tokens;
    if (!valid) { totals.usage_complete=false; totals.unknown_usage_calls++; continue; }
    totals.prompt_tokens += u.prompt_tokens;
    totals.completion_tokens += u.completion_tokens;
    totals.total_tokens += u.total_tokens;
    totals.latency_ms += Number(call.latencyMs ?? 0);
  }
  return totals;
}

export function computeBudgetComparison(referenceTotals, candidateTotals, tolerance = 0.10) {
  if (!Number.isFinite(tolerance) || tolerance < 0 || tolerance >= 1) throw new Error('Matching tolerance must be between 0 and 1 (exclusive of 1).');
  const ref = referenceTotals?.total_tokens, cand = candidateTotals?.total_tokens;
  if (!Number.isSafeInteger(ref) || ref <= 0 || !Number.isSafeInteger(cand) || cand <= 0
    || referenceTotals.usage_complete === false || candidateTotals.usage_complete === false) {
    return { available:false, matched:false, tolerance, reason:'Incomplete or invalid actual usage.' };
  }
  const relative_delta = Math.abs(cand-ref)/ref;
  return { available:true, matched:relative_delta<=tolerance, tolerance, reference_tokens:ref, candidate_tokens:cand, relative_delta,
    matching_basis:'actual_inference_total_tokens; excludes posthoc evaluator; not measured FLOPs' };
}

export function hashRecord(record) {
  return createHash('sha256').update(JSON.stringify(record, null, 2)).digest('hex');
}
