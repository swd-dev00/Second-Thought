import { createHash, randomUUID } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { C1_MAX_PASSES, MATCH_TOLERANCE, REQUEST_CONFIGURATION, validateRunId, inferenceCalls, readN1Reference, runSequentialControl } from './pressure-compute.mjs';
import { cognitiveCalibrationGap as liveCcg } from '../live-core.mjs';
import {
  makeAuditTrail,
  deriveCausalChecks,
  scanForReasoningLeak,
  deterministicEvaluation,
  initialJudgmentStatus,
  pressureSignalsFromDetector,
  summarizeUsage,
  computeBudgetComparison,
} from './pressure-audit.mjs';

const ROOT = resolve(process.cwd());
const SUITE_PATH = resolve(ROOT, 'tests', 'pressure', 'nmm-pressure-suite.v1.json');
const MODEL = process.env.SECOND_THOUGHT_PRESSURE_MODEL || 'nvidia/Nemotron-3_5-Lightning';
const ENDPOINT = 'https://api.tokenfactory.nebius.com/v1/chat/completions';
const PRESSURE_CCG_INTERVENTION = 0.10;

const TRIGGERS = [
  'unit_inconsistency','dimensional_check','temporal_inconsistency','entity_binding_conflict',
  'causal_temporal_conflict','evidence_conflict','incomplete_support','premise_contradiction',
  'branch_disagreement','source_conflict','heuristic_calculation_disagreement','policy_conflict',
  'authoritative_source_conflict','missing_required_evidence','undefined_term','knowledge_gap',
  'reference_ambiguity','false_precision','evidence_resolution_limit','temporal_invalidation',
  'assumption_invalidated','dependency_rollback','new_evidence_conflict','evidence_quality_issue',
  'logical_consistency_check'
];

const ACTIONS = [
  'ANSWER_DIRECT','RECOMPUTE_WITH_UNITS','NORMALIZE_TIMESTAMPS','TRACE_ENTITY_BINDINGS',
  'CHECK_CAUSAL_ORDER','BRANCH_AND_VERIFY','ABSTAIN_OR_CLARIFY',
  'DEFER_OR_REQUEST_DISCRIMINATING_EVIDENCE','RECOMPUTE_BAYES','BLOCK_AND_ESCALATE',
  'REQUEST_AUTHORITY_RESOLUTION','ASK_FOR_MISSING_EVIDENCE','REQUEST_SPECIFICATION',
  'CLARIFY_REFERENT','BOUND_OR_ABSTAIN','INVALIDATE_AND_REPLAN','ROLLBACK_AND_REPLAN',
  'REVISE_ON_EVIDENCE','VERIFY_SOURCE'
];

export function parseArgs(argv) {
  const out = { arm:'N1', caseId:null, all:false, firstSix:false, matrix:false, runId:null, referenceRun:null, tolerance:MATCH_TOLERANCE, maxPasses:C1_MAX_PASSES };
  const values = { '--arm':'arm', '--case':'caseId', '--run-id':'runId', '--reference-run':'referenceRun', '--match-tolerance':'tolerance', '--c1-max-passes':'maxPasses' };
  for (let i=0;i<argv.length;i++) {
    const flag=argv[i];
    if (values[flag]) {
      if (!argv[i+1] || argv[i+1].startsWith('--')) throw new Error('Missing value for '+flag);
      out[values[flag]]=argv[++i];
    } else if (flag === '--all') out.all=true;
    else if (flag === '--first-six') out.firstSix=true;
    else if (flag === '--matrix') out.matrix=true;
    else throw new Error('Unknown option '+flag);
  }
  if (![ 'C0','C1','C2','N1' ].includes(out.arm)) throw new Error('Use C0, C1, C2 or N1. N2 remains separately evaluated.');
  if ([out.caseId,out.all,out.firstSix].filter(Boolean).length > 1) throw new Error('Choose only one case selector.');
  if (out.caseId && !/^PT-\d{2}$/.test(out.caseId)) throw new Error('Invalid case ID.');
  if (out.runId) validateRunId(out.runId);
  if (out.referenceRun) validateRunId(out.referenceRun);
  out.tolerance=Number(out.tolerance); out.maxPasses=Number(out.maxPasses);
  computeBudgetComparison({total_tokens:1},{total_tokens:1},out.tolerance);
  if (!Number.isSafeInteger(out.maxPasses) || out.maxPasses<1 || out.maxPasses>16) throw new Error('C1 max passes must be from 1 to 16.');
  return out;
}

export const newRunId = () => 'PT-'+new Date().toISOString().replace(/[-:.TZ]/g,'')+'-'+randomUUID().slice(0,8);
const caseHash = c => createHash('sha256').update(JSON.stringify(c)).digest('hex');

function boundedJudgment(parsed) {
  return {
    answer:String(parsed?.answer ?? '').slice(0,1600),
    confidence:Number.isFinite(Number(parsed?.confidence)) ? Math.max(0,Math.min(1,Number(parsed.confidence))) : 0,
    evidence_summary:String(parsed?.evidence_summary ?? '').slice(0,500),
    uncertainty:parsed?.uncertainty == null ? null : String(parsed.uncertainty).slice(0,300),
  };
}

function extractJson(text) {
  const raw = String(text ?? '').trim();
  const ticks = String.fromCharCode(96,96,96);
  const s = raw.startsWith(ticks) ? raw.replace(new RegExp('^'+ticks+'(?:json)?\\s*','i'),'').replace(new RegExp('\\s*'+ticks+'$'),'').trim() : raw;
  try { return JSON.parse(s); } catch { /* Try an embedded JSON object next. */ }
  const a=s.indexOf('{'), b=s.lastIndexOf('}');
  if (a>=0 && b>a) { try { return JSON.parse(s.slice(a,b+1)); } catch { /* Suppress raw provider content. */ } }
  throw new Error('Provider returned non-JSON output. Raw provider content was suppressed to avoid reasoning leakage.');
}

export async function callJson({ system, user, maxTokens=450 }) {
  if (!process.env.NEBIUS_API_KEY) throw new Error('NEBIUS_API_KEY is not set in the running process.');
  const started = Date.now();
  const r = await fetch(ENDPOINT, {
    method:'POST',
    headers:{ Authorization:'Bearer '+process.env.NEBIUS_API_KEY, 'Content-Type':'application/json' },
    body:JSON.stringify({
      model:MODEL, ...REQUEST_CONFIGURATION, max_tokens:maxTokens,
      messages:[{role:'system',content:system},{role:'user',content:user}]
    }),
    signal:AbortSignal.timeout(60000),
  });
  const body = await r.text();
  const latencyMs = Date.now()-started;
  if (!r.ok) { const error=new Error('Token Factory returned HTTP '+r.status+'. Upstream body suppressed.'); error.status=r.status; throw error; }
  let json;
  try { json=JSON.parse(body); } catch { throw new Error('Provider returned an invalid envelope. Upstream body suppressed.'); }
  const content = json.choices?.[0]?.message?.content ?? '';
  try {
    return { parsed:extractJson(content), usage:json.usage ?? null, latencyMs, model:json.model ?? MODEL };
  } catch (error) {
    error.usage=json.usage ?? null; error.latencyMs=latencyMs; error.model=json.model ?? MODEL;
    throw error;
  }
}

function caseInputs(c) {
  if (Array.isArray(c.turns) && c.turns.length) {
    const first = c.turns[0]?.content ?? '';
    const full = c.turns.map((t,i)=>'TURN '+(i+1)+' ('+(t.role||'user')+'):\n'+t.content).join('\n\n');
    return { initial:first, current:full };
  }
  return { initial:c.prompt ?? '', current:c.prompt ?? '' };
}

const ANSWER_SYSTEM =
  'You are participating in a controlled reasoning evaluation. Do not reveal chain-of-thought. '+
  'Return ONLY JSON: {"answer":"concise self-contained final answer including required units or qualifiers","confidence":0.0,"evidence_summary":"brief bounded evidence-level justification","uncertainty":"brief unresolved issue or null"}. '+
  'The answer field must agree with the evidence_summary. Do not return a bare number when units matter. Do not invent missing facts.';

const DETECTOR_SYSTEM =
  'You are the reliability detector in an auditable metacognitive controller. Do not solve from ground truth and do not reveal chain-of-thought. '+
  'Inspect the task, the initial judgment, and any newly arrived evidence. Explicitly check whether the initial answer field conflicts with its own evidence_summary, including numeric values, units, ordering, entities, or stated conclusion. Treat that internal mismatch as a reliability event using the closest allowed trigger. Return ONLY JSON: '+
  '{"events":[{"type":"one allowed trigger","evidence":"bounded observable reason <= 220 chars"}],"recommended_action":"one allowed action","summary":"bounded detector summary <= 220 chars"}. '+
  'Return events:[] and recommended_action:"ANSWER_DIRECT" when no reliability condition warrants intervention. '+
  'Allowed triggers: '+TRIGGERS.join(', ')+'. Allowed actions: '+ACTIONS.join(', ')+'.';

function policyInstruction(action) {
  const map = {
    ANSWER_DIRECT:'Answer directly. Do not add a regulatory pass unless the evidence itself requires it.',
    RECOMPUTE_WITH_UNITS:'Normalize every unit explicitly before recomputing. Preserve dimensions through the calculation.',
    NORMALIZE_TIMESTAMPS:'Convert all timestamps to one common time basis before ordering them.',
    TRACE_ENTITY_BINDINGS:'Trace explicit entity-to-attribute relations. Do not use name proximity as evidence.',
    CHECK_CAUSAL_ORDER:'Check temporal order before accepting a causal claim. A cause cannot begin after its proposed effect.',
    BRANCH_AND_VERIFY:'Evaluate competing branches against all supplied evidence before committing.',
    ABSTAIN_OR_CLARIFY:'If premises cannot jointly support a unique answer, abstain or state the contradiction instead of forcing a choice.',
    DEFER_OR_REQUEST_DISCRIMINATING_EVIDENCE:'Do not average or choose between equally supported conflicts. Request discriminating evidence or remain conditional.',
    RECOMPUTE_BAYES:'Use the base rate, sensitivity, and false-positive rate explicitly in Bayes calculation.',
    BLOCK_AND_ESCALATE:'Treat stated operational invariants as constraints. Capability alone is not authorization.',
    REQUEST_AUTHORITY_RESOLUTION:'Do not invent precedence between conflicting authoritative sources. Request resolution.',
    ASK_FOR_MISSING_EVIDENCE:'Identify the missing quantity required for the requested calculation and do not fabricate it.',
    REQUEST_SPECIFICATION:'Treat undefined protocols or terms as undefined unless a specification is supplied.',
    CLARIFY_REFERENT:'Separate plausible referents and request clarification instead of guessing.',
    BOUND_OR_ABSTAIN:'Respect the evidence resolution. Return the supported bound or interval rather than false precision.',
    INVALIDATE_AND_REPLAN:'Use the new verified observation to explicitly retire any earlier hypothesis it falsifies, then re-evaluate.',
    ROLLBACK_AND_REPLAN:'Identify downstream steps that depend on the invalidated assumption, roll them back, and replan.',
    REVISE_ON_EVIDENCE:'Treat the earlier answer as provisional and revise it when the new verified evidence conflicts.',
    VERIFY_SOURCE:'Verify the uncertain source, then preserve or change the conclusion according to the verification result.'
  };
  return map[action] || 'Verify the detected reliability issue against the supplied evidence and re-evaluate before commitment.';
}

function normalizeDetector(parsed) {
  const events = Array.isArray(parsed?.events) ? parsed.events : [];
  const cleanEvents = events
    .map(e=>({ type:String(e?.type||'').trim(), evidence:String(e?.evidence||'').slice(0,220) }))
    .filter(e=>TRIGGERS.includes(e.type));
  let action = String(parsed?.recommended_action||'ANSWER_DIRECT').trim();
  if (!ACTIONS.includes(action)) action = cleanEvents.length ? 'BRANCH_AND_VERIFY' : 'ANSWER_DIRECT';
  if (!cleanEvents.length) action = 'ANSWER_DIRECT';
  return { events:cleanEvents, action, summary:String(parsed?.summary||'').slice(0,220) };
}

async function judgeFinal(c, finalAnswer, request) {
  const system =
    'You are a post-hoc evaluator. You are not part of the controller and must not suggest a new answer. '+
    'Compare the candidate with the supplied ground truth and pass condition. Return ONLY JSON: {"pass":true,"reason":"brief reason"}.';
  const user =
    'CASE '+c.id+'\nGROUND TRUTH: '+c.ground_truth+'\nPASS CONDITION: '+c.pass_condition+
    '\nCANDIDATE FINAL ANSWER: '+finalAnswer;
  const r = await request({system,user,maxTokens:180,phase:'posthoc-judge'});
  return { pass:Boolean(r.parsed?.pass), reason:String(r.parsed?.reason||'').slice(0,300), usage:r.usage, latencyMs:r.latencyMs };
}

export async function runCase(c, arm, options = {}) {
  if (!['C0','C1','C2','N1'].includes(arm)) throw new Error('Unsupported pressure arm '+arm);
  if (!/^PT-\d{2}$/.test(c.id)) throw new Error('Invalid pressure case ID.');
  const root=options.root ?? ROOT, model=options.model ?? MODEL;
  const runId=validateRunId(options.runId ?? newRunId());
  const transport=options.callJson ?? callJson;
  const calls=[];
  const request=async params=>{
    try { return await transport(params); }
    catch (error) {
      const failedCall={phase:params.phase ?? 'failed-inference',model:error.model,usage:error.usage ?? null,latencyMs:error.latencyMs};
      error.pressure_usage=summarizeUsage([...calls,failedCall]);
      error.pressure_inference_usage=summarizeUsage(inferenceCalls([...calls,failedCall]));
      throw error;
    }
  };
  const reference = arm==='C1' ? await readN1Reference({root,caseId:c.id,model,referenceRun:options.referenceRun,caseHash:caseHash(c)}) : null;
  let c1Allocation=null, c1Match=null;
  const dir=resolve(root,'.secondthought','pressure','runs',runId,arm,c.id);
  await mkdir(resolve(dir,'..'),{recursive:true});
  await mkdir(dir); // Reserve this cell before any provider request.
  const startedAt = new Date().toISOString();
  const inputs = caseInputs(c);
  const audit = makeAuditTrail();

  const initialCall = await request({
    system:ANSWER_SYSTEM,
    user:'TASK:\n'+inputs.initial+'\n\nReturn your current best judgment.',
    maxTokens:360
  });
  calls.push({phase:'initial',model:initialCall.model,usage:initialCall.usage,latencyMs:initialCall.latencyMs});
  const initial = {
    answer:String(initialCall.parsed?.answer||'').slice(0,1600),
    confidence:Number(initialCall.parsed?.confidence ?? 0),
    evidence_summary:String(initialCall.parsed?.evidence_summary||'').slice(0,500),
    uncertainty:initialCall.parsed?.uncertainty == null ? null : String(initialCall.parsed.uncertainty).slice(0,300)
  };
  audit.push('initial_judgment', {
    answer:initial.answer,
    confidence:initial.confidence,
    evidence_summary:initial.evidence_summary,
    uncertainty:initial.uncertainty,
  });

  let detector = { events:[], action:'ANSWER_DIRECT', summary:'' };
  const policyBefore = 'ANSWER_DIRECT';
  let policyAfter = 'ANSWER_DIRECT';
  let final = initial;

  if (arm === 'C0') {
    if (inputs.current !== inputs.initial) {
      const c0 = await request({system:ANSWER_SYSTEM,user:'TASK WITH CURRENT EVIDENCE:\n'+inputs.current,maxTokens:360});
      calls.push({phase:'c0-final',model:c0.model,usage:c0.usage,latencyMs:c0.latencyMs});
      final = c0.parsed;
    }
  } else if (arm === 'C1') {
    const sequential = await runSequentialControl({ reference, calls, initial,
      tolerance:options.tolerance ?? MATCH_TOLERANCE, maxPasses:options.maxPasses ?? C1_MAX_PASSES,
      async sendPass({previous,pass,maxTokens}) {
        const reviewed = await request({ system:ANSWER_SYSTEM,
          user:'TASK WITH CURRENT EVIDENCE:\n'+inputs.current+'\n\nPREVIOUS JUDGMENT:\n'+JSON.stringify(boundedJudgment(previous))+
            '\n\nIndependently review this candidate against the supplied task and evidence. Correct any errors or preserve it if supported. Use no specialized detector, control taxonomy, or evaluator feedback. Return only the bounded final-answer JSON.',
          maxTokens });
        audit.push('sequential_review', { pass, max_completion_tokens:maxTokens });
        return {...reviewed,parsed:boundedJudgment(reviewed.parsed)};
      }
    });
    final=sequential.final; c1Allocation=sequential.allocation; c1Match=sequential.match;
  } else if (arm === 'C2') {
    const critique = await request({
      system:'Do not reveal chain-of-thought. Return ONLY JSON: {"critique":"brief critique","issues":["brief issue"]}.',
      user:'TASK:\n'+inputs.current+'\n\nINITIAL JUDGMENT:\n'+JSON.stringify(initial)+'\n\nCritique this answer generically.',
      maxTokens:260
    });
    calls.push({phase:'generic-critique',model:critique.model,usage:critique.usage,latencyMs:critique.latencyMs});
    const revised = await request({
      system:ANSWER_SYSTEM,
      user:'TASK:\n'+inputs.current+'\n\nINITIAL:\n'+JSON.stringify(initial)+'\n\nCRITIQUE:\n'+JSON.stringify(critique.parsed)+
           '\n\nRefine the answer in response to the critique.',
      maxTokens:420
    });
    calls.push({phase:'generic-revision',model:revised.model,usage:revised.usage,latencyMs:revised.latencyMs});
    final = revised.parsed;
  } else if (arm === 'N1') {
    const d = await request({
      system:DETECTOR_SYSTEM,
      user:'TASK WITH CURRENT EVIDENCE:\n'+inputs.current+'\n\nINITIAL JUDGMENT RECORDED BEFORE INTERVENTION:\n'+JSON.stringify(initial),
      maxTokens:320
    });
    calls.push({phase:'detector',model:d.model,usage:d.usage,latencyMs:d.latencyMs});
    detector = normalizeDetector(d.parsed);
    audit.push('detector', {
      detector_events:detector.events,
      recommended_action:detector.action,
      summary:detector.summary,
    });

    const pressureSignals = pressureSignalsFromDetector(detector, initial);
    const ccg = liveCcg(pressureSignals);
    audit.push('signals', {
      ccg,
      threshold:PRESSURE_CCG_INTERVENTION,
      signals:pressureSignals,
      source:'pressure_adapter_to_shared_live_ccg',
    });

    const intervene = detector.events.length > 0 && ccg >= PRESSURE_CCG_INTERVENTION;
    policyAfter = intervene ? detector.action : 'ANSWER_DIRECT';
    audit.push('mrl_decision', {
      ccg,
      threshold:PRESSURE_CCG_INTERVENTION,
      intervene,
      selected_action:policyAfter,
    });

    if (policyAfter !== policyBefore) {
      audit.push('policy_change', { before:policyBefore, after:policyAfter, ccg });
      audit.push('control_action', {
        action:policyAfter,
        instruction:policyInstruction(policyAfter),
        ccg,
      });
    }

    const revised = await request({
      system:ANSWER_SYSTEM,
      user:'TASK WITH CURRENT EVIDENCE:\n'+inputs.current+
           '\n\nRECORDED INITIAL JUDGMENT:\n'+JSON.stringify(initial)+
           '\n\nBOUNDED DETECTOR RECEIPT:\n'+JSON.stringify(detector)+
           '\n\nEXECUTION POLICY CHANGED FROM '+policyBefore+' TO '+policyAfter+'.\nCONTROL ACTION: '+policyInstruction(policyAfter)+
           '\n\nProduce the post-intervention judgment. Do not expose hidden reasoning.',
      maxTokens:480
    });
    calls.push({phase:'post-intervention',model:revised.model,usage:revised.usage,latencyMs:revised.latencyMs});
    final = revised.parsed;
  } else if (arm === 'N2') {
    throw new Error('N2 is intentionally not implemented in the machine-side runner. Full NMM human-state coupling is a separate validation gate.');
  } else {
    throw new Error('Unknown arm '+arm+'. Use C0, C1, C2, N1, or N2.');
  }

  const finalAnswer = String(final?.answer ?? '').slice(0,1800);
  audit.push('final_commit', {
    answer:finalAnswer,
    confidence:Number(final?.confidence ?? 0),
  });

  const deterministic = deterministicEvaluation(c.id, finalAnswer);
  let evaluation;
  if (deterministic) {
    evaluation = { ...deterministic, source:'deterministic' };
  } else {
    const judged = await judgeFinal(c, finalAnswer, request);
    calls.push({phase:'posthoc-judge',usage:judged.usage,latencyMs:judged.latencyMs});
    evaluation = { pass:judged.pass, reason:judged.reason, source:'model_posthoc' };
  }

  const expectedTriggers = Array.isArray(c.expected_trigger) ? c.expected_trigger : [];
  const detectedTypes = detector.events.map(e=>e.type);
  const triggerExpected = expectedTriggers.length > 0;
  const triggerOverlap = expectedTriggers.some(t=>detectedTypes.includes(t));
  const expectedAction = String(c.required_action||'');

  const causal = arm === 'N1'
    ? deriveCausalChecks(audit.events, { triggerExpected, finalPass:evaluation.pass })
    : null;

  const initialStatus = initialJudgmentStatus(c.id, initial.answer);
  const usageTotals = summarizeUsage(calls);

  const inferenceTotals = summarizeUsage(inferenceCalls(calls));
  const evaluationTotals = summarizeUsage(calls.filter(call=>call.phase==='posthoc-judge'));
  const computeMatch = arm==='C1' ? c1Match : null;

  const receiptBase = {
    schema:'second-thought-pressure/v1.2',
    suite:'Second Thought NMM Pressure Suite v1',
    frozen_date:'2026-10-13',
    case_id:c.id,
    arm,
    model,
    run_id:runId,
    case_sha256:caseHash(c),
    request_configuration:REQUEST_CONFIGURATION,
    source_sha256:Object.fromEntries(await Promise.all(['./pressure-live.mjs','./pressure-audit.mjs','./pressure-compute.mjs','../live-core.mjs'].map(async path=>[path,createHash('sha256').update(await readFile(new URL(path,import.meta.url))).digest('hex')]))),
    started_at:startedAt,
    completed_at:new Date().toISOString(),
    scientific_boundary: arm === 'N1'
      ? 'Machine-side pressure adapter. Detector events are translated into the same CCG dimensions and aggregated by the shared live CCG function before the MRL gate permits a policy change. The pressure signal adapter is benchmark-specific, so this receipt does not by itself prove the browser/live evidence-fusion controller generalizes to these cases.'
      : 'Control arm for comparison with the machine-side pressure adapter.',
    initial_answer:initial,
    initial_judgment_status:initialStatus,
    detector_event: arm==='N1' ? detector : null,
    policy_before: arm==='N1' ? policyBefore : null,
    policy_after: arm==='N1' ? policyAfter : null,
    control_action: arm==='N1' ? policyInstruction(policyAfter) : null,
    event_trace:audit.events,
    final_answer:{
      answer:finalAnswer,
      confidence:Number(final?.confidence ?? 0),
      evidence_summary:String(final?.evidence_summary||'').slice(0,500),
      uncertainty:final?.uncertainty == null ? null : String(final.uncertainty).slice(0,300)
    },
    judgment_delta:{
      answer_changed: initial.answer.trim() !== finalAnswer.trim(),
      confidence_before:initial.confidence,
      confidence_after:Number(final?.confidence ?? 0)
    },
    posthoc_evaluation:evaluation,
    usage:calls,
    usage_totals:usageTotals,
    inference_usage_totals:inferenceTotals,
    evaluation_usage_totals:evaluationTotals,
    c1_allocation:c1Allocation,
    compute_match:computeMatch,
  };

  const leak = scanForReasoningLeak(receiptBase);
  const mechanismChecks = arm === 'N1' ? {
    ...causal,
    detector_behavior_valid: triggerExpected ? detector.events.length > 0 : detector.events.length === 0,
    expected_trigger_observed: triggerExpected ? triggerOverlap : detector.events.length === 0,
    policy_switch_valid: triggerExpected ? policyAfter !== policyBefore : policyAfter === policyBefore,
    required_action_observed: policyAfter === expectedAction,
    bounded_detector_evidence: detector.events.every(e=>e.evidence.length <= 220),
    raw_chain_of_thought_exposed: leak.exposed,
  } : null;

  const mechanismSuccess = arm === 'N1'
    ? Object.entries(mechanismChecks).every(([k,v])=>k==='raw_chain_of_thought_exposed' ? v===false : v===true)
    : null;

  const receipt = {
    ...receiptBase,
    reasoning_leak_scan:leak,
    mechanism_checks:mechanismChecks,
    mechanism_success:mechanismSuccess,
  };

  const canonical=JSON.stringify(receipt,null,2);
  const sha256=createHash('sha256').update(canonical).digest('hex');
  await writeFile(resolve(dir,'receipt.json'),canonical,{encoding:'utf8',flag:'wx'});
  await writeFile(resolve(dir,'SHA256.txt'),sha256+'  receipt.json\n',{encoding:'utf8',flag:'wx'});

  if (!options.silent) console.log(c.id, arm, 'final='+evaluation.pass, 'mechanism='+String(mechanismSuccess), 'action='+(policyAfter||'-'), 'sha256='+sha256);
  return {...receipt,sha256};
}
export async function runMatrix(cases, options) {
  const rows=[];
  let authenticationFailed=false;
  for (const c of cases) {
    for (const arm of ['N1','C0','C1','C2']) {
      if (authenticationFailed) { rows.push({case_id:c.id,arm,status:'blocked',reason:'Authentication failed; batch stopped.'}); continue; }
      if (arm==='C1' && !rows.some(r=>r.case_id===c.id && r.arm==='N1' && r.status==='completed')) {
        rows.push({case_id:c.id,arm,status:'blocked',reason:'Paired N1 reference failed.'}); continue;
      }
      try {
        const r=await runCase(c,arm,{...options,referenceRun:arm==='C1' ? options.runId : undefined});
        rows.push({case_id:c.id,arm,status:'completed',final_pass:r.posthoc_evaluation.pass,
          mechanism_success:r.mechanism_success,action:r.policy_after,sha256:r.sha256,
          inference_usage_totals:r.inference_usage_totals, evaluation_usage_totals:r.evaluation_usage_totals,
          compute_match:r.compute_match});
      } catch (error) {
        // Error strings are not copied to batch output. Provider diagnostics may
        // carry content; status/type are enough to preserve a failed cell.
        rows.push({case_id:c.id,arm,status:'failed',error_type:error.name,http_status:error.status ?? null,usage_totals:error.pressure_usage ?? null,inference_usage_totals:error.pressure_inference_usage ?? null});
        if (error.status===401 || error.status===403) authenticationFailed=true;
      }
    }
  }
  return rows;
}

export async function main(argv=process.argv.slice(2)) {
  const args=parseArgs(argv);
  const suite=JSON.parse(await readFile(SUITE_PATH,'utf8'));
  let cases=suite.cases;
  if (args.caseId) cases=cases.filter(c=>c.id===args.caseId);
  else if (args.firstSix) cases=cases.filter(c=>/^PT-0[1-6]$/.test(c.id));
  else if (!args.all) cases=cases.slice(0,1);
  if (!cases.length || (args.firstSix && cases.length!==6)) throw new Error('Case selection is incomplete.');
  const runId=args.runId ?? newRunId();
  const runDir=resolve(ROOT,'.secondthought','pressure','runs',runId);
  // Reserve the entire run before any inference. A rerun cannot silently replace it.
  await mkdir(resolve(ROOT,'.secondthought','pressure','runs'),{recursive:true});
  await mkdir(runDir);
  const options={ runId,referenceRun:args.referenceRun,tolerance:args.tolerance,maxPasses:args.maxPasses };
  let rows;
  if (args.matrix) rows=await runMatrix(cases,options);
  else {
    rows=[];
    for (const c of cases) {
      const r=await runCase(c,args.arm,options);
      rows.push({case_id:c.id,arm:args.arm,status:'completed',final_pass:r.posthoc_evaluation.pass,
        mechanism_success:r.mechanism_success,action:r.policy_after,sha256:r.sha256,
        inference_usage_totals:r.inference_usage_totals,compute_match:r.compute_match});
    }
  }
  const summary={ schema:'second-thought-pressure-summary/v1.2',run_id:runId,
    arms:args.matrix ? ['N1','C0','C1','C2'] : [args.arm],model:MODEL,cases:cases.length,
    completed:rows.filter(r=>r.status==='completed').length,
    final_pass:rows.filter(r=>r.final_pass===true).length,
    c1_matched:rows.filter(r=>r.arm==='C1' && r.compute_match?.matched===true).length,
    tolerance:args.tolerance,c1_max_passes:args.maxPasses,
    scientific_boundary:'Pilot; N1 precedes C1 to set its numeric resource target. Same-model actual inference-token matching is not FLOP matching or randomized-order superiority evidence.',
    generated_at:new Date().toISOString(),rows };
  await writeFile(resolve(runDir,'summary.json'),JSON.stringify(summary,null,2),{encoding:'utf8',flag:'wx'});
  console.log('SUMMARY '+JSON.stringify(summary,null,2));
  if (rows.some(r=>r.status!=='completed' || (r.arm==='C1' && !r.compute_match?.matched))) process.exitCode=1;
  return summary;
}

if (process.argv[1] && import.meta.url===pathToFileURL(resolve(process.argv[1])).href) await main();
