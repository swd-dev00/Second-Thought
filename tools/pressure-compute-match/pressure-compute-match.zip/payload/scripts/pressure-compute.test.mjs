import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtemp, readFile, mkdir, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve } from "node:path";
import {
  computeBudgetComparison,
  summarizeUsage,
  scanForReasoningLeak,
} from "./pressure-audit.mjs";
import {
  readN1Reference,
  runSequentialControl,
  REQUEST_CONFIGURATION,
} from "./pressure-compute.mjs";
import { runCase, runMatrix, parseArgs, callJson } from "./pressure-live.mjs";

const model = "nvidia/Nemotron-3_5-Lightning";
const usage = (prompt, completion) => ({
  prompt_tokens: prompt,
  completion_tokens: completion,
  total_tokens: prompt + completion,
});
const initial = {
  answer: "5.0 mL",
  confidence: 0.9,
  evidence_summary: "Initial candidate.",
  uncertainty: null,
};
const reference = {
  totals: { total_tokens: 1566 },
  model,
  sha256: "a".repeat(64),
  configuration_evidence: "recorded",
};
const initialCall = () => ({
  phase: "initial",
  model,
  usage: usage(162, 105),
  latencyMs: 1,
});
const answer = {
  answer: "5000 µL",
  confidence: 0.9,
  evidence_summary: "Actuator units normalized.",
  uncertainty: null,
};
const suite = JSON.parse(
  await readFile(
    new URL("../tests/pressure/nmm-pressure-suite.v1.json", import.meta.url),
    "utf8",
  ),
);

async function temporary(t) {
  const root = await mkdtemp(resolve(tmpdir(), "pressure-compute-"));
  t.after(() => rm(root, { recursive: true, force: true }));
  return root;
}

async function seal(root, record) {
  const dir = resolve(root, ".secondthought", "pressure", "N1", record.case_id);
  await mkdir(dir, { recursive: true });
  const text = JSON.stringify(record, null, 2);
  await writeFile(resolve(dir, "receipt.json"), text);
  await writeFile(
    resolve(dir, "SHA256.txt"),
    createHash("sha256").update(text).digest("hex") + "  receipt.json\n",
  );
  return dir;
}

function referenceRecord(extra = []) {
  const calls = [
    { phase: "initial", model, usage: usage(162, 91) },
    { phase: "detector", model, usage: usage(613, 124) },
    { phase: "post-intervention", model, usage: usage(444, 132) },
    ...extra,
  ];
  return {
    arm: "N1",
    case_id: "PT-01",
    model,
    usage: calls,
    usage_totals: summarizeUsage(calls),
    final_answer: { answer: "This target must not be returned to C1." },
  };
}

test("C1 spends on bounded generic passes until actual usage enters the existing 10% band", async () => {
  const calls = [initialCall()];
  const caps = [];
  const run = await runSequentialControl({
    reference,
    calls,
    initial,
    async sendPass({ maxTokens }) {
      caps.push(maxTokens);
      return { parsed: answer, model, usage: usage(288, 106), latencyMs: 1 };
    },
  });
  assert.equal(run.allocation.passes, 3);
  assert.equal(run.match.candidate_tokens, 1449);
  assert.equal(run.match.matched, true);
  assert.equal(run.allocation.lower_tokens, 1410);
  assert.equal(run.allocation.upper_tokens, 1722);
  assert.ok(caps[2] < caps[1]);
});

test("pass cap retains a correct-but-unmatched result instead of pretending unused budget was spent", async () => {
  const run = await runSequentialControl({
    reference,
    calls: [initialCall()],
    initial,
    maxPasses: 1,
    sendPass: async () => ({ parsed: answer, model, usage: usage(288, 106) }),
  });
  assert.equal(run.match.candidate_tokens, 661);
  assert.equal(run.match.matched, false);
  assert.equal(run.final.answer, "5000 µL");
  assert.equal(run.allocation.stop_reason, "pass_limit");
});

test("missing or malformed usage cannot produce a matching claim", async () => {
  for (const u of [
    null,
    usage(-1, 20),
    { ...usage(10, 20), total_tokens: 90 },
  ]) {
    const totals = summarizeUsage([{ usage: u }]);
    assert.equal(totals.usage_complete, false);
    assert.equal(
      computeBudgetComparison(reference.totals, totals).matched,
      false,
    );
  }
  for (const n of [-1, NaN, Infinity])
    assert.equal(
      computeBudgetComparison({ total_tokens: n }, { total_tokens: 100 })
        .matched,
      false,
    );
  const run = await runSequentialControl({
    reference,
    calls: [{ phase: "initial", usage: null }],
    initial,
    sendPass: () =>
      assert.fail("No additional requests with incomplete accounting"),
  });
  assert.equal(run.allocation.stop_reason, "incomplete_usage");
});

test("actual prompt overshoot is preserved and further calls stop", async () => {
  let requests = 0;
  const run = await runSequentialControl({
    reference,
    calls: [initialCall()],
    initial,
    sendPass: async () => {
      requests++;
      return { parsed: answer, model, usage: usage(1900, 100) };
    },
  });
  assert.equal(requests, 1);
  assert.equal(run.match.matched, false);
  assert.equal(run.match.candidate_tokens, 2267);
  assert.equal(run.allocation.stop_reason, "actual_usage_overshoot");
});

test("reference verifies its digest and excludes post-hoc evaluator cost and target answer", async (t) => {
  const root = await temporary(t);
  await seal(
    root,
    referenceRecord([{ phase: "posthoc-judge", usage: usage(300, 100) }]),
  );
  const r = await readN1Reference({ root, caseId: "PT-01", model });
  assert.equal(r.totals.total_tokens, 1566);
  assert.equal(
    r.configuration_evidence,
    "legacy-v1.1-harness-defaults-assumed",
  );
  assert.equal(Object.hasOwn(r, "final_answer"), false);
  const dir = resolve(root, ".secondthought", "pressure", "N1", "PT-01");
  await writeFile(
    resolve(dir, "SHA256.txt"),
    "b".repeat(64) + "  receipt.json",
  );
  await assert.rejects(
    readN1Reference({ root, caseId: "PT-01", model }),
    /digest mismatch/,
  );
});

test("reference rejects different model, case, configuration and inconsistent ledger", async (t) => {
  const root = await temporary(t);
  for (const [change, pattern] of [
    [{ model: "other-model" }, /model mismatch/],
    [{ case_sha256: "different" }, /case content mismatch/],
    [
      { request_configuration: { ...REQUEST_CONFIGURATION, temperature: 1 } },
      /configuration mismatch/,
    ],
    [{ usage_totals: { total_tokens: 2000 } }, /contradicts/],
  ]) {
    await seal(root, { ...referenceRecord(), ...change });
    await assert.rejects(
      readN1Reference({ root, caseId: "PT-01", model, caseHash: "expected" }),
      pattern,
    );
  }
});

test("C1 reference and output collision checks run before any provider request", async (t) => {
  const root = await temporary(t);
  await assert.rejects(
    runCase(suite.cases[0], "C1", {
      root,
      runId: "no-reference",
      callJson: () => assert.fail(),
    }),
  );
  await mkdir(
    resolve(
      root,
      ".secondthought",
      "pressure",
      "runs",
      "collision",
      "C0",
      "PT-01",
    ),
    { recursive: true },
  );
  await assert.rejects(
    runCase(suite.cases[0], "C0", {
      root,
      runId: "collision",
      callJson: () => assert.fail(),
    }),
    /EEXIST/,
  );
});

test("C1 controller input contains no N1 diagnostic, policy or post-hoc feedback", async (t) => {
  const root = await temporary(t);
  await seal(root, referenceRecord());
  const requests = [];
  const r = await runCase(suite.cases[0], "C1", {
    root,
    runId: "c1-inputs",
    silent: true,
    model,
    async callJson(req) {
      requests.push(req);
      return {
        parsed: requests.length === 1 ? initial : answer,
        model,
        usage: requests.length === 1 ? usage(162, 105) : usage(288, 106),
        latencyMs: 1,
      };
    },
  });
  assert.equal(r.compute_match.matched, true);
  assert.equal(r.detector_event, null);
  assert.ok(
    requests.every(
      (req) =>
        !/(GROUND TRUTH|PASS CONDITION|RECOMPUTE_WITH_UNITS|BOUNDED DETECTOR RECEIPT)/.test(
          req.user,
        ),
    ),
  );
  assert.equal(
    r.event_trace.filter((e) => e.kind === "sequential_review").length,
    3,
  );
  assert.equal(scanForReasoningLeak(r).exposed, false);
});

test("six-case mocked matrix yields 24 cells with paired references and distinct evaluator accounting", async (t) => {
  const root = await temporary(t);
  const cases = suite.cases.slice(0, 6);
  const rows = await runMatrix(cases, {
    root,
    runId: "mock-matrix",
    silent: true,
    model,
    async callJson(req) {
      const c =
        cases.find((c) => req.user.includes(c.prompt)) ??
        cases.find((c) => req.user.includes("CASE " + c.id));
      assert.ok(c, "All requests belong to a supplied case");
      if (req.system.includes("post-hoc evaluator"))
        return {
          parsed: { pass: true, reason: "Mocked scorer only." },
          model,
          usage: usage(300, 50),
        };
      if (req.system.includes("reliability detector"))
        return {
          parsed: {
            events: [
              {
                type: c.expected_trigger[0],
                evidence: "Mocked observable issue.",
              },
            ],
            recommended_action: c.required_action,
            summary: "Mocked diagnostic.",
          },
          model,
          usage: usage(613, 124),
        };
      if (req.user.includes("EXECUTION POLICY"))
        return {
          parsed: { ...answer, answer: c.ground_truth },
          model,
          usage: usage(444, 132),
        };
      if (req.user.includes("PREVIOUS JUDGMENT"))
        return {
          parsed: { ...answer, answer: c.ground_truth },
          model,
          usage: usage(288, 106),
        };
      return { parsed: initial, model, usage: usage(162, 91) };
    },
  });
  assert.equal(rows.length, 24);
  assert.ok(rows.every((row) => row.status === "completed"));
  assert.equal(
    rows.filter((row) => row.arm === "C1" && row.compute_match.matched).length,
    6,
  );
  assert.ok(
    rows
      .filter((row) => row.arm === "N1")
      .every((row) => row.inference_usage_totals.total_tokens === 1566),
  );
  assert.ok(
    rows.find((row) => row.case_id === "PT-03" && row.arm === "N1")
      .evaluation_usage_totals.total_tokens > 0,
  );
  const n1 = await readFile(
    resolve(
      root,
      ".secondthought",
      "pressure",
      "runs",
      "mock-matrix",
      "N1",
      "PT-01",
      "receipt.json",
    ),
  );
  const digest = (
    await readFile(
      resolve(
        root,
        ".secondthought",
        "pressure",
        "runs",
        "mock-matrix",
        "N1",
        "PT-01",
        "SHA256.txt",
      ),
      "utf8",
    )
  ).split(/\s+/)[0];
  assert.equal(createHash("sha256").update(n1).digest("hex"), digest);
});

test("matrix aborts authenticated work after 401 while retaining all failed/blocked cells", async (t) => {
  const root = await temporary(t);
  let requests = 0;
  const rows = await runMatrix(suite.cases.slice(0, 6), {
    root,
    runId: "unauthorized",
    model,
    callJson: async () => {
      requests++;
      const error = new Error("Not copied to summary");
      error.status = 401;
      throw error;
    },
  });
  assert.equal(requests, 1);
  assert.equal(rows.length, 24);
  assert.equal(rows.filter((r) => r.status === "failed").length, 1);
  assert.equal(rows.filter((r) => r.status === "blocked").length, 23);
});

test("CLI preserves defaults, selects the matrix explicitly and rejects unsafe or unsupported options", () => {
  const defaults = parseArgs([]);
  assert.equal(defaults.tolerance, 0.1);
  assert.equal(defaults.maxPasses, 8);
  assert.equal(parseArgs(["--matrix", "--first-six"]).matrix, true);
  for (const args of [
    ["--run-id", "../escape"],
    ["--arm", "N2"],
    ["--case"],
    ["--all", "--first-six"],
    ["--match-tolerance", "NaN"],
    ["--c1-max-passes", "0"],
  ])
    assert.throws(() => parseArgs(args));
});

test("transport errors suppress upstream bodies and retain status", async (t) => {
  const originalFetch = globalThis.fetch,
    originalKey = process.env.NEBIUS_API_KEY;
  t.after(() => {
    globalThis.fetch = originalFetch;
    if (originalKey === undefined) delete process.env.NEBIUS_API_KEY;
    else process.env.NEBIUS_API_KEY = originalKey;
  });
  process.env.NEBIUS_API_KEY = "offline-test-only";
  globalThis.fetch = async () =>
    new Response("UPSTREAM_CONTENT_MUST_NOT_LEAK", { status: 401 });
  await assert.rejects(
    callJson({ system: "Test", user: "Test" }),
    (error) =>
      error.status === 401 && !error.message.includes("UPSTREAM_CONTENT"),
  );
});

test("truncated structured replies retain usage without exposing provider content", async (t) => {
  const originalFetch = globalThis.fetch;
  const originalKey = process.env.NEBIUS_API_KEY;
  t.after(() => {
    globalThis.fetch = originalFetch;
    if (originalKey === undefined) delete process.env.NEBIUS_API_KEY;
    else process.env.NEBIUS_API_KEY = originalKey;
  });
  process.env.NEBIUS_API_KEY = "offline-test-only";
  globalThis.fetch = async () =>
    new Response(
      JSON.stringify({
        model,
        usage: usage(200, 160),
        choices: [{ message: { content: "UPSTREAM_PRIVATE_CONTENT" } }],
      }),
    );
  await assert.rejects(
    callJson({ system: "Test", user: "Test" }),
    (error) =>
      error.usage.total_tokens === 360 &&
      !error.message.includes("UPSTREAM_PRIVATE_CONTENT"),
  );
  globalThis.fetch = async () => new Response("UPSTREAM_INVALID_ENVELOPE");
  await assert.rejects(
    callJson({ system: "Test", user: "Test" }),
    (error) => !error.message.includes("UPSTREAM_INVALID_ENVELOPE"),
  );
});
