# Pressure control matching: implementation and Windows run

This note describes an update to the uploaded pressure harness. It does not revise Sierra Warren's original NMM research protocol or the frozen 20-case suite. No new live pressure-test results were produced in this cloud pass.

## What changed

C1 previously made exactly one extra pass with a 520-token completion cap, then compared its actual usage with N1. The cap was an allocation, not a guarantee of consumed tokens. The uploaded PT-01 records confirm C1 used 661 tokens against N1's 1,566; `matched:false` was correct. The N1 receipt's exact file digest was independently verified as `377b40892f8986e4b521cb6f5224ebcb9468f382ea77cd1c105726c34090f159`.

C1 now performs substantive generic sequential review, using the previous candidate and the same supplied task/evidence. Its matching target is the inference usage in a digest-verified N1 reference. It receives no N1 detector, policy, answer, or evaluator feedback. The original **10%** matching tolerance remains the default, configurable before a run with `--match-tolerance`. The default maximum is eight additional passes, configurable from 1–16 with `--c1-max-passes`.

For the uploaded PT-01 target, the default acceptable range is **1,410–1,722 actual inference tokens**. C1 stops when its actual call ledger enters that band. Each subsequent completion cap is bounded using the remaining budget and observed prior prompt usage. The first prompt estimate adds a 180-token allowance; the minimum remaining completion allocation is 160. These are forecasts, not an exact model tokenizer. A short result, incomplete usage, unexpected prompt growth, or pass limit can leave a run unmatched. Such a run is preserved and never relabeled as matched merely because its cap was large.

No padding, evaluator-driven answer selection, specialized detector, hidden N1 hints, or post-hoc retry-until-pass is used. The final judgment is the last scheduled review candidate. Model/configuration incompatibility or damaged reference receipts block matching.

Matching is based on **actual inference-token totals**, not measured FLOPs or latency equality. Prompt/completion composition, model identity, caching, and provider runtime can still differ. Every call's original usage remains recorded. A legacy v1.1 reference lacks generation-configuration metadata; the new receipt explicitly marks its defaults as assumed. New v1.2 reference receipts record configuration, case digest, and harness source digests.

Post-hoc evaluator calls now have separate usage totals and do not inflate the reasoning budget. Total billed usage is retained separately. PT-01 and PT-02 use the existing deterministic evaluators; PT-03–PT-06 still use the original post-hoc model judge. Those four outcomes are not independent deterministic measurements. Evaluators and detector logic are otherwise unchanged.

## Evidence preservation

New artifacts are written under `.secondthought/pressure/runs/<run-id>/<arm>/<case>/`. Existing `.secondthought/pressure/N1/PT-01/receipt.json` and control receipts remain untouched. Reusing an existing run or cell fails before inference rather than replacing evidence.

The matrix runs N1 before C1 for each case to supply only its numeric token target. This is a reference-budget pilot with a declared order, not a randomized superiority study. It records all 24 cells, including failed and blocked cells, and stops authenticated work after an HTTP 401/403. A nonzero exit means an execution failure or an unmatched C1 comparison; it does not mean an expected control-arm answer failure was hidden.

The recorded event-order checks retain their existing meaning. They establish the trace's sequence; incremental causal benefit still requires controlled comparisons and detector/trigger ablation.

## Apply to the authoritative Windows checkout

Extract `pressure-compute-match.zip` into a separate folder and run its installer:

```powershell
& .\Apply-PressureComputeMatch.ps1 -Root 'D:\AI\Second-Thought'
```

The installer checks the stated base HEAD and the uploaded source digests before copying anything. It backs up replaced files outside the checkout, copies only the listed harness updates, and runs the three test files below. A failure restores replaced files and removes only newly installed files. It does not pull, switch branches, stage, commit, or alter receipts, the suite, the original research protocol, or any environment file. If the Windows files changed after upload, it stops rather than overwriting newer work.

## Run with the working Windows key

Run from `D:\AI\Second-Thought`. The existing key must be set as `NEBIUS_API_KEY` in that PowerShell process; no key is included in this patch.

```powershell
Set-Location 'D:\AI\Second-Thought'
node --test scripts/pressure-audit.test.mjs scripts/pressure-suite.test.mjs scripts/pressure-compute.test.mjs
```

First, try C1 against the uploaded legacy PT-01 N1 reference, preserving it:

```powershell
node scripts/pressure-live.mjs --arm C1 --case PT-01 --run-id pt01-c1-matched-v1
```

Then execute the requested six-case/four-arm pilot:

```powershell
node scripts/pressure-live.mjs --matrix --first-six --run-id pt01-06-matrix-v1
```

For a declared 5% sensitivity run, use a new run ID and add `--match-tolerance 0.05`. Do not change tolerance after seeing outcomes. A rerun always needs a new run ID. The summary is `.secondthought/pressure/runs/<run-id>/summary.json` and includes matching coverage, actual inference/evaluator usage, outcomes, and per-cell digests. For a standalone C1 comparison against a new N1 run, pass `--reference-run <n1-run-id>`.

## Verification completed here

- Uploaded N1 receipt digest matched exactly; original C0/C1/C2 outcomes and usage were inspected.
- **25 tests passed**, including the original 12 and new allocation/accounting/integrity tests.
- A **mocked** six-case matrix produced 24 cells and exercised six matched C1 pairs. This is plumbing validation, not live model evidence.
- Syntax and scoped JavaScript lint passed. The copied frozen suite, original protocol, original test files, and legacy receipts retain their uploaded bytes.
- The Windows PowerShell installer was reviewed and its manifest/package validated in cloud; PowerShell execution was not available here.
- Remote Desktop Commander is not callable in this session. The Windows checkout has not been edited by this cloud session. The cloud inference binding previously returned 401, so the live commands must run where the working key is configured unless that binding is updated.
