[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
param(
    [string]$Root = 'D:\AI\Second-Thought',
    [switch]$RunMatrix,
    [ValidatePattern('^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$')]
    [string]$RunId = ('matrix-' + [guid]::NewGuid().ToString('N'))
)

$ErrorActionPreference = 'Stop'
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw | ConvertFrom-Json
$rootPath = [IO.Path]::GetFullPath($Root).TrimEnd('\', '/')
$payloadRoot = Join-Path $PSScriptRoot 'payload'
Get-Command node -ErrorAction Stop | Out-Null
Get-Command git -ErrorAction Stop | Out-Null

function Resolve-InRoot([string]$Base, [string]$Relative) {
    $path = [IO.Path]::GetFullPath((Join-Path $Base $Relative))
    $prefix = $Base.TrimEnd('\', '/') + [IO.Path]::DirectorySeparatorChar
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Path outside declared root: $Relative"
    }
    return $path
}
function File-Digest([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

$head = & git -C $rootPath rev-parse HEAD
if ($LASTEXITCODE -ne 0 -or $head.Trim() -ne $manifest.base_head) {
    throw 'Checkout HEAD differs from the supplied base. No files were changed.'
}
$changed = @()
foreach ($entry in $manifest.files) {
    $source = Resolve-InRoot $payloadRoot $entry.path
    if ((File-Digest $source) -ne $entry.updated_sha256) { throw "Payload digest mismatch: $($entry.path)" }
    $destination = Resolve-InRoot $rootPath $entry.path
    if ((Test-Path -LiteralPath $destination) -and -not (Test-Path -LiteralPath $destination -PathType Leaf)) {
        throw "Destination is not a file: $($entry.path). No files were changed."
    }
    if (Test-Path -LiteralPath $destination -PathType Leaf) {
        $current = File-Digest $destination
        if ($current -eq $entry.updated_sha256) { continue }
        if (-not $entry.original_sha256 -or $current -ne $entry.original_sha256) {
            throw "Windows file changed since upload: $($entry.path). No files were changed."
        }
    } elseif ($entry.original_sha256) {
        throw "Original file is missing: $($entry.path). No files were changed."
    }
    $changed += $entry
}
foreach ($guard in $manifest.unchanged_guards) {
    $path = Resolve-InRoot $rootPath $guard.path
    if (-not (Test-Path -LiteralPath $path -PathType Leaf) -or (File-Digest $path) -ne $guard.sha256) {
        throw "Unchanged dependency/source differs: $($guard.path). No files were changed."
    }
}
if (-not $PSCmdlet.ShouldProcess($rootPath, 'Apply hash-checked pressure harness update and run offline tests')) { return }

$backup = Join-Path $env:TEMP ('SecondThought-pressure-backup-' + [guid]::NewGuid())
$applied = @()
try {
    foreach ($entry in $changed) {
        $destination = Resolve-InRoot $rootPath $entry.path
        $old = $null
        if (Test-Path -LiteralPath $destination -PathType Leaf) {
            $old = Resolve-InRoot $backup $entry.path
            New-Item -ItemType Directory -Path (Split-Path -Parent $old) -Force | Out-Null
            Copy-Item -LiteralPath $destination -Destination $old -ErrorAction Stop
        }
        New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
        $applied += [pscustomobject]@{ destination = $destination; backup = $old }
        Copy-Item -LiteralPath (Resolve-InRoot $payloadRoot $entry.path) -Destination $destination -ErrorAction Stop
        if ((File-Digest $destination) -ne $entry.updated_sha256) { throw "Installed digest mismatch: $($entry.path)" }
    }
    Push-Location $rootPath
    try {
        & node --test scripts/pressure-audit.test.mjs scripts/pressure-suite.test.mjs scripts/pressure-compute.test.mjs
        if ($LASTEXITCODE -ne 0) { throw 'Offline pressure tests failed.' }
    } finally { Pop-Location }
} catch {
    foreach ($change in $applied) {
        if ($change.backup) {
            Copy-Item -LiteralPath $change.backup -Destination $change.destination -Force -ErrorAction Stop
        } elseif (Test-Path -LiteralPath $change.destination -PathType Leaf) {
            Remove-Item -LiteralPath $change.destination -ErrorAction Stop
        }
    }
    throw
}
Write-Host 'Pressure matching update installed; offline tests passed.'
if ($changed.Count) { Write-Host "Backups: $backup" }
Write-Host 'No git pull, branch switch, staging, commit, or receipt changes were made.'
Write-Host "Next, from $rootPath :"
Write-Host 'node scripts/pressure-live.mjs --arm C1 --case PT-01 --run-id pt01-c1-matched-v1'
Write-Host 'node scripts/pressure-live.mjs --matrix --first-six --run-id pt01-06-matrix-v1'

if ($RunMatrix) {
    if (-not $env:NEBIUS_API_KEY) {
        throw 'Live run requires NEBIUS_API_KEY in this PowerShell process. Source update is installed; no live request was made.'
    }
    Push-Location $rootPath
    try {
        & node scripts/pressure-live.mjs --matrix --first-six --run-id $RunId
        Write-Host "Recorded summary: $rootPath\.secondthought\pressure\runs\$RunId\summary.json"
        if ($LASTEXITCODE -ne 0) { throw 'Pilot includes execution failures or unmatched C1 cells. Inspect its preserved summary.' }
    } finally { Pop-Location }
}
