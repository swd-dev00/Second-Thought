# Second Thought pressure matching update

This package is based on the uploaded, uncommitted Windows files at `D:\AI\Second-Thought`, base HEAD `816f6659dc343f050cf6ab1f038e0c1d811d2910`. It contains two replacement script files and three new files. It contains no original research manuscript, frozen suite, key, or receipt payload.

Extract to a folder outside the checkout. In PowerShell, run:

```powershell
& .\Apply-PressureComputeMatch.ps1 -Root 'D:\AI\Second-Thought' -RunMatrix
```

The installer preflights every source/dependency hash, backs up replaced files to a unique temporary directory, runs the offline tests, and rolls back its changes if they fail. It accepts already-installed identical files, stops on newer or different Windows files, and never pulls or commits. `-WhatIf` performs a read-only preflight. The PowerShell installer has not been executed in this cloud environment; Node tests and package hashes have been checked here.

With `-RunMatrix`, the installer runs the requested live matrix only after source validation and offline tests pass. It requires the working key in that same Windows PowerShell process and chooses a unique run ID. Omit `-RunMatrix` for installation/tests only. For separate pilot commands:

```powershell
Set-Location 'D:\AI\Second-Thought'
node scripts/pressure-live.mjs --arm C1 --case PT-01 --run-id pt01-c1-matched-v1
node scripts/pressure-live.mjs --matrix --first-six --run-id pt01-06-matrix-v1
```

Use a new run ID for any rerun. C1 attempts actual inference-token matching with the original 10% tolerance and at most eight additional generic review passes; it can remain unmatched and exits nonzero rather than inventing a match. This is not measured FLOP equality. Full method and limitations are in `payload/docs/research/PT_COMPUTE_MATCH_IMPLEMENTATION.md`.

25 offline tests passed, including a mocked 24-cell matrix. No new live pressure outcomes or NMM superiority are claimed. The original PT-01 N1 digest was independently verified. Remote Desktop Commander was unavailable, so this package has not been applied to Windows by this session.
